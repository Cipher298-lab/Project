package www.CognifyzInternship.com;
import java.util.Scanner;
//Level 2 ,Task 1
public class TicTacToe {
    private static char[][] board = new char[3][3];
    private static char currentPlayer;
    private static boolean gameEnded;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean playAgain = true;
        
        while (playAgain) {
            initializeGame();
            playGame();
            playAgain = askToPlayAgain();}
        
        System.out.println("Thank you for playing with cognifyintern!");
        scanner.close();}

    private static void initializeGame() {for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j] = ' ';
            }}
        currentPlayer = 'X';
        gameEnded = false;
    }

    private static void playGame() {
        System.out.println("TTT_GAME!");
        System.out.println("Player 1: X, Player 2: O\n");
        
        while (!gameEnded) {
            printBoard();
            getPlayerMove();
            checkGameState();
            switchPlayer();
        } }

    private static void printBoard() {
        System.out.println("-------------");
        for (int i = 0; i < 3; i++) {
            System.out.print("| ");
            for (int j = 0; j < 3; j++) {
                System.out.print(board[i][j] + " | ");
            }
            System.out.println("\n-------------");
        }
    }

    private static void getPlayerMove() {
        int row, col;
        boolean validInput = false;

        do {
            System.out.printf("Player %s, enter your move (row [1-3] column [1-3]): ", currentPlayer);
            row = scanner.nextInt() - 1;
            col = scanner.nextInt() - 1;

            if (row >= 0 && row < 3 && col >= 0 && col < 3) {
                if (board[row][col] == ' ') {
                    board[row][col] = currentPlayer;
                    validInput = true;
                } else {
                    System.out.println("This cell is already occupied!");
                }
            } else {
                System.out.println("Wrong Input Value! Row and column must be in range between 1 and 3.");
            }
        } while (!validInput);}

    private static void checkGameState() {
     
        if (checkWin()) {
            printBoard();
            System.out.printf("Player %s wins!\n", currentPlayer);
            gameEnded = true;
        } 
        else if (isBoardFull()) {
            printBoard();
            System.out.println("It's a draw!");
            gameEnded = true;
        }
    }

    private static boolean checkWin() {
        for (int i = 0; i < 3; i++) {  if (board[i][0] != ' ' && 
                board[i][0] == board[i][1] && 
                board[i][1] == board[i][2]) {
                return true;
            }}for (int j = 0; j < 3; j++) {
            if (board[0][j] != ' ' && 
                board[0][j] == board[1][j] && 
                board[1][j] == board[2][j]) {
                return true;
            } }

        if (board[0][0] != ' ' && 
            board[0][0] == board[1][1] && 
            board[1][1] == board[2][2]) {
            return true;
        }

        if (board[0][2] != ' ' && 
            board[0][2] == board[1][1] && 
            board[1][1] == board[2][0]) {
            return true;
        }

        return false; }

    private static boolean isBoardFull() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == ' ') {
                    return false;  } } }
        return true;}

    private static void switchPlayer() {
        if (!gameEnded) {
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
        } }

    private static boolean askToPlayAgain() {
        System.out.print("Play again? (y/n): ");
        String response = scanner.next().toLowerCase();
        return response.equals("y") || response.equals("yes");
    }
}